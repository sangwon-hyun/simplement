#' simplement
#'
#' This package contains helpers for simulations and numerical experiments.
#' 
#' @docType package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
